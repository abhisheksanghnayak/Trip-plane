import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

import Layout from './components/layout/Layout';
import HomePage from './pages/HomePage';
import DestinationPage from './pages/DestinationPage';
import BudgetCalculator from './pages/BudgetCalculator';
import TripPlanner from './pages/TripPlanner';
import Recommendations from './pages/Recommendations';
import NotFoundPage from './pages/NotFoundPage';

// Create a client
const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/destinations/:id" element={<DestinationPage />} />
            <Route path="/budget-calculator" element={<BudgetCalculator />} />
            <Route path="/trip-planner" element={<TripPlanner />} />
            <Route path="/recommendations" element={<Recommendations />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </Layout>
      </Router>
    </QueryClientProvider>
  );
}

export default App;