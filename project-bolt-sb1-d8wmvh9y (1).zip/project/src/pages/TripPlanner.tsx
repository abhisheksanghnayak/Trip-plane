import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, MapPin, Plus, Trash2, Clock, Save } from 'lucide-react';

const TripPlanner: React.FC = () => {
  const [destination, setDestination] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [itinerary, setItinerary] = useState<Array<{ day: number; activities: Array<{ time: string; description: string }> }>>([
    {
      day: 1,
      activities: [
        { time: '09:00', description: 'Breakfast at hotel' },
        { time: '10:30', description: 'Visit main attractions' },
        { time: '13:00', description: 'Lunch at local restaurant' }
      ]
    }
  ]);

  // Add a new day to the itinerary
  const addDay = () => {
    const newDay = {
      day: itinerary.length + 1,
      activities: [{ time: '09:00', description: '' }]
    };
    setItinerary([...itinerary, newDay]);
  };

  // Remove a day from the itinerary
  const removeDay = (dayIndex: number) => {
    const updatedItinerary = itinerary.filter((_, index) => index !== dayIndex);
    // Update day numbers
    const reIndexed = updatedItinerary.map((day, index) => ({
      ...day,
      day: index + 1
    }));
    setItinerary(reIndexed);
  };

  // Add an activity to a specific day
  const addActivity = (dayIndex: number) => {
    const updatedItinerary = [...itinerary];
    updatedItinerary[dayIndex].activities.push({ time: '', description: '' });
    setItinerary(updatedItinerary);
  };

  // Remove an activity from a specific day
  const removeActivity = (dayIndex: number, activityIndex: number) => {
    const updatedItinerary = [...itinerary];
    updatedItinerary[dayIndex].activities = updatedItinerary[dayIndex].activities.filter(
      (_, index) => index !== activityIndex
    );
    setItinerary(updatedItinerary);
  };

  // Update an activity's time or description
  const updateActivity = (dayIndex: number, activityIndex: number, key: 'time' | 'description', value: string) => {
    const updatedItinerary = [...itinerary];
    updatedItinerary[dayIndex].activities[activityIndex][key] = value;
    setItinerary(updatedItinerary);
  };

  // Popular destinations for autocomplete
  const popularDestinations = [
    'Paris, France',
    'Tokyo, Japan',
    'New York, USA',
    'Rome, Italy',
    'Bali, Indonesia',
    'Barcelona, Spain',
    'London, UK',
    'Sydney, Australia',
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-4xl mx-auto"
      >
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Trip Planner</h1>
          <p className="text-lg text-gray-600">
            Create your perfect travel itinerary day by day
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-8">
          <div className="p-6 sm:p-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Trip Details</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div>
                <label htmlFor="destination" className="block text-sm font-medium text-gray-700 mb-2">
                  Destination
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <MapPin className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="destination"
                    type="text"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    placeholder="Where are you going?"
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    list="popular-destinations"
                  />
                  <datalist id="popular-destinations">
                    {popularDestinations.map((dest, index) => (
                      <option key={index} value={dest} />
                    ))}
                  </datalist>
                </div>
              </div>
              
              <div>
                <label htmlFor="start-date" className="block text-sm font-medium text-gray-700 mb-2">
                  Start Date
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Calendar className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="start-date"
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="end-date" className="block text-sm font-medium text-gray-700 mb-2">
                  End Date
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Calendar className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="end-date"
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {itinerary.map((day, dayIndex) => (
            <motion.div 
              key={dayIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: dayIndex * 0.1 }}
              className="bg-white rounded-xl shadow-lg overflow-hidden"
            >
              <div className="bg-blue-600 text-white px-6 py-4 flex justify-between items-center">
                <h3 className="text-lg font-semibold">Day {day.day}</h3>
                <button
                  onClick={() => removeDay(dayIndex)}
                  className="text-white hover:text-red-200 transition-colors duration-200"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
              
              <div className="p-6">
                <div className="space-y-4">
                  {day.activities.map((activity, activityIndex) => (
                    <div key={activityIndex} className="flex items-start gap-4">
                      <div className="w-24">
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Clock className="h-4 w-4 text-gray-400" />
                          </div>
                          <input
                            type="text"
                            value={activity.time}
                            onChange={(e) => 
                              updateActivity(dayIndex, activityIndex, 'time', e.target.value)
                            }
                            placeholder="Time"
                            className="block w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                          />
                        </div>
                      </div>
                      <div className="flex-grow">
                        <input
                          type="text"
                          value={activity.description}
                          onChange={(e) => 
                            updateActivity(dayIndex, activityIndex, 'description', e.target.value)
                          }
                          placeholder="Add activity description"
                          className="block w-full px-3 py-2 text-sm border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                      <button
                        onClick={() => removeActivity(dayIndex, activityIndex)}
                        className="text-gray-400 hover:text-red-500 transition-colors duration-200"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
                
                <button
                  onClick={() => addActivity(dayIndex)}
                  className="mt-4 flex items-center text-blue-600 text-sm font-medium hover:text-blue-700"
                >
                  <Plus className="h-4 w-4 mr-1" /> Add Activity
                </button>
              </div>
            </motion.div>
          ))}
          
          <button
            onClick={addDay}
            className="w-full py-3 border-2 border-dashed border-blue-300 rounded-lg text-blue-600 font-medium hover:bg-blue-50 transition-colors duration-200 flex items-center justify-center"
          >
            <Plus className="h-5 w-5 mr-2" /> Add Day
          </button>
          
          <div className="mt-8 flex justify-center">
            <button className="px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center">
              <Save className="h-5 w-5 mr-2" /> Save Itinerary
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default TripPlanner;