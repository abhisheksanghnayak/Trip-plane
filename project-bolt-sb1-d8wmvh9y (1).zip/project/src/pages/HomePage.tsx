import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, DollarSign, MapPin, Compass } from 'lucide-react';

import DestinationSearchBar from '../components/search/DestinationSearchBar';
import FeaturedDestinations from '../components/destinations/FeaturedDestinations';
import TestimonialCarousel from '../components/testimonials/TestimonialCarousel';

const HomePage: React.FC = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5,
      },
    },
  };

  const features = [
    {
      icon: <Search className="h-6 w-6 text-blue-600" />,
      title: "Smart Destination Search",
      description: "Find perfect destinations with our AI-powered contextual search.",
      linkTo: "/destinations",
    },
    {
      icon: <DollarSign className="h-6 w-6 text-blue-600" />,
      title: "Budget Calculator",
      description: "Plan your travel expenses with our dynamic budget estimator.",
      linkTo: "/budget-calculator",
    },
    {
      icon: <MapPin className="h-6 w-6 text-blue-600" />,
      title: "Trip Planner",
      description: "Create customized itineraries for your perfect journey.",
      linkTo: "/trip-planner",
    },
    {
      icon: <Compass className="h-6 w-6 text-blue-600" />,
      title: "Personalized Recommendations",
      description: "Get tailored travel suggestions based on your preferences.",
      linkTo: "/recommendations",
    },
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[70vh] min-h-[500px] flex items-center">
        <div className="absolute inset-0 z-0">
          <div 
            className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30 z-10"
            style={{ mixBlendMode: 'multiply' }}
          />
          <img 
            src="https://images.pexels.com/photos/3155666/pexels-photo-3155666.jpeg" 
            alt="Travel destination background" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl"
          >
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-4">
              Discover Your Next Adventure
            </h1>
            <p className="text-xl text-white/90 mb-8">
              Let our AI-powered travel assistant help you plan the perfect trip
            </p>
            <DestinationSearchBar />
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="container mx-auto">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Plan Your Journey with WanderNest
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Our AI-powered tools make travel planning easier than ever before
            </p>
          </motion.div>

          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
          >
            {features.map((feature, index) => (
              <motion.div 
                key={index}
                variants={itemVariants}
                className="bg-gray-50 rounded-lg p-6 hover:shadow-lg transition-shadow duration-300"
              >
                <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600 mb-4">{feature.description}</p>
                <Link 
                  to={feature.linkTo}
                  className="text-blue-600 font-medium hover:text-blue-700 inline-flex items-center"
                >
                  Try now <span className="ml-1">→</span>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Featured Destinations */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-blue-50">
        <div className="container mx-auto">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Featured Destinations
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Explore our curated selection of top destinations around the world
            </p>
          </motion.div>
          <FeaturedDestinations />
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="container mx-auto">
          <motion.div 
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              What Our Travelers Say
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Real experiences from WanderNest users around the globe
            </p>
          </motion.div>
          <TestimonialCarousel />
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-blue-600">
        <div className="container mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold text-white mb-4">
              Ready to Start Your Journey?
            </h2>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Create your personalized travel plan today and explore the world with confidence
            </p>
            <Link
              to="/trip-planner"
              className="inline-block px-6 py-3 bg-white text-blue-600 font-medium text-lg rounded-lg hover:bg-gray-100 transition-colors duration-200"
            >
              Plan Your Trip Now
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;