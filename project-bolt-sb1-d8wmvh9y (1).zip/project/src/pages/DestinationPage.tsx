import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin, Calendar, DollarSign, Star, Clock, Globe, Thermometer, Users, ChevronRight } from 'lucide-react';
 
import { FEATURED_DESTINATIONS } from '../data/destinations';

const DestinationPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [destination, setDestination] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    // In a real app, we would fetch from an API
    // Simulate API call with setTimeout
    setLoading(true);
    setTimeout(() => {
      const foundDestination = FEATURED_DESTINATIONS.find(
        (dest) => dest.id === id
      );
      setDestination(foundDestination || null);
      setLoading(false);
    }, 500);
  }, [id]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!destination) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">Destination not found</h1>
        <p className="text-gray-600 mb-6">The destination you're looking for doesn't exist.</p>
        <Link
          to="/"
          className="inline-block px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors duration-200"
        >
          Return Home
        </Link>
      </div>
    );
  }

  const tabContent = {
    overview: (
      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-4">About {destination.name}</h2>
        <p className="text-gray-700 mb-6">
          {destination.fullDescription || "Detailed description coming soon..."}
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-blue-50 rounded-lg p-5">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Best Time to Visit</h3>
            <div className="flex items-start">
              <Calendar className="h-5 w-5 text-blue-600 mt-0.5 mr-2 flex-shrink-0" />
              <p className="text-gray-700">
                {destination.bestTimeToVisit || "April to June and September to November are ideal with mild temperatures and fewer crowds."}
              </p>
            </div>
          </div>
          <div className="bg-blue-50 rounded-lg p-5">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Budget Considerations</h3>
            <div className="flex items-start">
              <DollarSign className="h-5 w-5 text-blue-600 mt-0.5 mr-2 flex-shrink-0" />
              <p className="text-gray-700">
                {destination.budgetInfo || "A typical daily budget ranges from $100-$200 per person, depending on your accommodation and dining preferences."}
              </p>
            </div>
          </div>
        </div>
        
        <h2 className="text-xl font-bold text-gray-900 mb-4">Highlights</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {(destination.highlights || [
            "Historic City Center",
            "Local Cuisine",
            "Cultural Experiences",
            "Natural Landscapes",
            "Museums and Galleries",
            "Shopping Districts"
          ]).map((highlight, index) => (
            <div key={index} className="flex items-center">
              <ChevronRight className="h-4 w-4 text-blue-600 mr-2" />
              <span className="text-gray-700">{highlight}</span>
            </div>
          ))}
        </div>
      </div>
    ),
    attractions: (
      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-6">Top Attractions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {(destination.attractions || [
            {
              name: "Landmark One",
              description: "A popular landmark with historical significance and beautiful views.",
              image: "https://images.pexels.com/photos/1486577/pexels-photo-1486577.jpeg"
            },
            {
              name: "Landmark Two",
              description: "Another impressive landmark known for its unique architecture.",
              image: "https://images.pexels.com/photos/16094928/pexels-photo-16094928/free-photo-of-coast-of-greece.jpeg"
            },
            {
              name: "Landmark Three",
              description: "A stunning natural attraction that showcases the region's beauty.",
              image: "https://images.pexels.com/photos/1591373/pexels-photo-1591373.jpeg"
            },
            {
              name: "Landmark Four",
              description: "A cultural center where visitors can experience local traditions.",
              image: "https://images.pexels.com/photos/1680140/pexels-photo-1680140.jpeg"
            }
          ]).map((attraction, index) => (
            <div key={index} className="bg-white rounded-lg overflow-hidden shadow-md">
              <div className="h-48 overflow-hidden">
                <img 
                  src={attraction.image} 
                  alt={attraction.name} 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-4">
                <h3 className="font-bold text-lg text-gray-900 mb-2">{attraction.name}</h3>
                <p className="text-gray-600 text-sm">{attraction.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    ),
    practical: (
      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-6">Practical Information</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-lg p-5 shadow-sm border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
              <Globe className="h-5 w-5 text-blue-600 mr-2" /> Language
            </h3>
            <p className="text-gray-700">
              {destination.language || "The official language is English, though you may hear various local dialects."}
            </p>
          </div>
          <div className="bg-white rounded-lg p-5 shadow-sm border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
              <Thermometer className="h-5 w-5 text-blue-600 mr-2" /> Climate
            </h3>
            <p className="text-gray-700">
              {destination.climate || "Moderate climate with warm summers (20-30°C) and mild winters (5-15°C)."}
            </p>
          </div>
          <div className="bg-white rounded-lg p-5 shadow-sm border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
              <Clock className="h-5 w-5 text-blue-600 mr-2" /> Best Time to Visit
            </h3>
            <p className="text-gray-700">
              {destination.bestTimeToVisit || "April to June and September to November offer pleasant weather and fewer tourists."}
            </p>
          </div>
          <div className="bg-white rounded-lg p-5 shadow-sm border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
              <Users className="h-5 w-5 text-blue-600 mr-2" /> Local Customs
            </h3>
            <p className="text-gray-700">
              {destination.customs || "Respect local traditions by dressing modestly when visiting religious sites."}
            </p>
          </div>
        </div>
        
        <div className="bg-blue-50 rounded-lg p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">Travel Tips</h3>
          <ul className="space-y-3">
            {(destination.travelTips || [
              "Book accommodation in advance during peak season.",
              "Public transportation is efficient and affordable for getting around.",
              "Try the local cuisine at smaller family-run restaurants for authentic flavors.",
              "Carry a water bottle and stay hydrated, especially during summer months."
            ]).map((tip, index) => (
              <li key={index} className="flex items-start">
                <ChevronRight className="h-4 w-4 text-blue-600 mt-1 mr-2 flex-shrink-0" />
                <span className="text-gray-700">{tip}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    )
  };

  return (
    <div className="pb-12">
      {/* Hero Header */}
      <div className="relative h-[50vh] min-h-[400px]">
        <div className="absolute inset-0 z-0">
          <div 
            className="absolute inset-0 bg-gradient-to-t from-black/70 to-black/30 z-10"
          />
          <img 
            src={destination.imageUrl} 
            alt={destination.name} 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative z-10 container mx-auto px-4 h-full flex flex-col justify-end pb-12">
          <div className="flex items-center text-blue-200 mb-2">
            <MapPin className="h-5 w-5 mr-1" />
            <span>{destination.country}</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            {destination.name}
          </h1>
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <Star className="h-5 w-5 text-yellow-400 fill-yellow-400" />
              <span className="ml-1 text-white">{destination.rating || "4.8"}</span>
            </div>
            <span className="text-white">•</span>
            <span className="text-white">{destination.regionType || "Coastal City"}</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Left column - Main content */}
          <div className="md:w-2/3">
            {/* Tabs */}
            <div className="border-b border-gray-200 mb-8">
              <nav className="flex space-x-8">
                {['overview', 'attractions', 'practical'].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`py-4 px-1 text-sm font-medium border-b-2 ${
                      activeTab === tab
                        ? 'border-blue-600 text-blue-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    {tab.charAt(0).toUpperCase() + tab.slice(1)}
                  </button>
                ))}
              </nav>
            </div>

            {/* Tab content */}
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              {tabContent[activeTab as keyof typeof tabContent]}
            </motion.div>
          </div>

          {/* Right column - Sidebar */}
          <div className="md:w-1/3">
            {/* Budget Info Card */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
              <div className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Plan Your Trip</h3>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center text-gray-700">
                    <DollarSign className="h-5 w-5 text-blue-600 mr-2" />
                    <span>Average cost</span>
                  </div>
                  <span className="font-semibold">${destination.averageCost || "120"}/day</span>
                </div>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center text-gray-700">
                    <Calendar className="h-5 w-5 text-blue-600 mr-2" />
                    <span>Suggested days</span>
                  </div>
                  <span className="font-semibold">{destination.suggestedDays || "3-5"} days</span>
                </div>
                <div className="flex gap-2">
                  <Link
                    to="/budget-calculator"
                    className="flex-1 text-center py-2 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700 transition-colors duration-200"
                  >
                    Calculate Budget
                  </Link>
                  <Link
                    to="/trip-planner"
                    className="flex-1 text-center py-2 bg-white text-blue-600 font-medium rounded-md border border-blue-600 hover:bg-blue-50 transition-colors duration-200"
                  >
                    Plan Trip
                  </Link>
                </div>
              </div>
            </div>

            {/* Weather Card */}
            <div className="bg-blue-50 rounded-lg p-6 mb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Weather</h3>
              <div className="space-y-4">
                {["Jan-Mar", "Apr-Jun", "Jul-Sep", "Oct-Dec"].map((season, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="text-gray-700">{season}</span>
                    <div className="flex items-center">
                      <Thermometer className="h-4 w-4 text-blue-600 mr-1" />
                      <span className="text-gray-900">{
                        index === 0 ? "5-15°C" :
                        index === 1 ? "15-25°C" :
                        index === 2 ? "20-30°C" :
                        "10-20°C"
                      }</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Similar Destinations */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Similar Destinations</h3>
                <div className="space-y-4">
                  {FEATURED_DESTINATIONS.filter(d => d.id !== destination.id).slice(0, 3).map((dest) => (
                    <Link 
                      key={dest.id}
                      to={`/destinations/${dest.id}`}
                      className="flex items-center space-x-3 group"
                    >
                      <div className="w-16 h-16 rounded-lg overflow-hidden">
                        <img 
                          src={dest.imageUrl} 
                          alt={dest.name} 
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                      </div>
                      <div>
                        <h4 className="text-gray-900 font-medium group-hover:text-blue-600 transition-colors">{dest.name}</h4>
                        <p className="text-sm text-gray-500">{dest.country}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DestinationPage;