import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { DollarSign, Calendar, Users, Utensils, Bed, Plane, CarTaxiFront as Taxi, MapPin } from 'lucide-react';

const BudgetCalculator: React.FC = () => {
  const [destination, setDestination] = useState('');
  const [duration, setDuration] = useState(7);
  const [travelers, setTravelers] = useState(2);
  const [accommodation, setAccommodation] = useState(100);
  const [food, setFood] = useState(50);
  const [transport, setTransport] = useState(30);
  const [activities, setActivities] = useState(40);
  const [totalBudget, setTotalBudget] = useState(0);

  useEffect(() => {
    // Calculate total budget
    const total = duration * travelers * (accommodation + food + transport + activities);
    setTotalBudget(total);
  }, [duration, travelers, accommodation, food, transport, activities]);

  const categoryIcons = {
    accommodation: <Bed className="h-5 w-5" />,
    food: <Utensils className="h-5 w-5" />,
    transport: <Taxi className="h-5 w-5" />,
    activities: <MapPin className="h-5 w-5" />,
  };

  const categories = [
    { name: 'Accommodation', key: 'accommodation', value: accommodation, setValue: setAccommodation, min: 20, max: 500, icon: categoryIcons.accommodation },
    { name: 'Food & Drinks', key: 'food', value: food, setValue: setFood, min: 10, max: 200, icon: categoryIcons.food },
    { name: 'Local Transport', key: 'transport', value: transport, setValue: setTransport, min: 5, max: 100, icon: categoryIcons.transport },
    { name: 'Activities', key: 'activities', value: activities, setValue: setActivities, min: 0, max: 200, icon: categoryIcons.activities },
  ];

  const popularDestinations = [
    'Paris, France',
    'Tokyo, Japan',
    'New York, USA',
    'Rome, Italy',
    'Bali, Indonesia',
    'Barcelona, Spain',
    'London, UK',
    'Sydney, Australia',
  ];

  const formatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-4xl mx-auto"
      >
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Travel Budget Calculator</h1>
          <p className="text-lg text-gray-600">
            Plan your trip expenses with our AI-powered budget estimator
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 sm:p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Trip Details</h2>
                
                <div className="mb-4">
                  <label htmlFor="destination" className="block text-sm font-medium text-gray-700 mb-2">
                    Destination
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <MapPin className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="destination"
                      type="text"
                      value={destination}
                      onChange={(e) => setDestination(e.target.value)}
                      placeholder="Where are you going?"
                      className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      list="popular-destinations"
                    />
                    <datalist id="popular-destinations">
                      {popularDestinations.map((dest, index) => (
                        <option key={index} value={dest} />
                      ))}
                    </datalist>
                  </div>
                </div>

                <div className="mb-4">
                  <label htmlFor="duration" className="block text-sm font-medium text-gray-700 mb-2">
                    Duration (days)
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Calendar className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="duration"
                      type="number"
                      min="1"
                      max="30"
                      value={duration}
                      onChange={(e) => setDuration(parseInt(e.target.value) || 1)}
                      className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>

                <div className="mb-4">
                  <label htmlFor="travelers" className="block text-sm font-medium text-gray-700 mb-2">
                    Number of Travelers
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Users className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="travelers"
                      type="number"
                      min="1"
                      max="10"
                      value={travelers}
                      onChange={(e) => setTravelers(parseInt(e.target.value) || 1)}
                      className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>

              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Daily Expenses (per person)</h2>
                
                {categories.map((category) => (
                  <div key={category.key} className="mb-6">
                    <div className="flex justify-between items-center mb-2">
                      <label htmlFor={category.key} className="flex items-center text-sm font-medium text-gray-700">
                        <span className="mr-2 text-blue-600">{category.icon}</span>
                        {category.name}
                      </label>
                      <span className="font-medium text-blue-600">{formatter.format(category.value)}</span>
                    </div>
                    <input
                      id={category.key}
                      type="range"
                      min={category.min}
                      max={category.max}
                      value={category.value}
                      onChange={(e) => category.setValue(parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>{formatter.format(category.min)}</span>
                      <span>{formatter.format(category.max)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-gray-200">
              <div className="bg-blue-50 rounded-lg p-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Estimated Total Budget</h3>
                    <p className="text-sm text-gray-600">
                      {duration} days • {travelers} {travelers === 1 ? 'person' : 'people'}
                    </p>
                  </div>
                  <div className="text-2xl font-bold text-blue-600">
                    {formatter.format(totalBudget)}
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {categories.map((category) => (
                    <div key={category.key} className="text-center">
                      <div className="text-blue-600 mb-1">{category.icon}</div>
                      <div className="text-sm font-medium text-gray-700">
                        {formatter.format(category.value * duration * travelers)}
                      </div>
                      <div className="text-xs text-gray-500">{category.name}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 text-center">
                <p className="text-sm text-gray-500 mb-4">
                  This is an estimate based on average prices. Actual costs may vary.
                </p>
                <button className="px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors duration-200">
                  Save Estimate
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default BudgetCalculator;