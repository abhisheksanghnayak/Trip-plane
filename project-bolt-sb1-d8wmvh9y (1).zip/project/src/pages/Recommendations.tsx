import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Filter, MapPin, Calendar, DollarSign, Compass, Users, Heart, ThumbsUp, ThumbsDown } from 'lucide-react';

import { FEATURED_DESTINATIONS } from '../data/destinations';

const Recommendations: React.FC = () => {
  const [preferences, setPreferences] = useState({
    climate: '',
    activity: '',
    budget: '',
    duration: '',
    travelStyle: ''
  });
  
  const [showRecommendations, setShowRecommendations] = useState(false);
  const [recommendedDestinations, setRecommendedDestinations] = useState<any[]>([]);

  const climateOptions = [
    { value: 'warm', label: 'Warm & Sunny' },
    { value: 'mild', label: 'Mild & Temperate' },
    { value: 'cold', label: 'Cold & Snowy' },
    { value: 'tropical', label: 'Tropical' },
  ];
  
  const activityOptions = [
    { value: 'culture', label: 'Culture & History' },
    { value: 'nature', label: 'Nature & Outdoors' },
    { value: 'beach', label: 'Beaches & Relaxation' },
    { value: 'food', label: 'Food & Cuisine' },
    { value: 'adventure', label: 'Adventure & Sports' },
  ];
  
  const budgetOptions = [
    { value: 'budget', label: 'Budget-Friendly' },
    { value: 'moderate', label: 'Moderate' },
    { value: 'luxury', label: 'Luxury' },
  ];
  
  const durationOptions = [
    { value: 'weekend', label: 'Weekend Getaway (1-3 days)' },
    { value: 'short', label: 'Short Trip (4-7 days)' },
    { value: 'medium', label: 'Medium Trip (1-2 weeks)' },
    { value: 'long', label: 'Long Trip (2+ weeks)' },
  ];
  
  const travelStyleOptions = [
    { value: 'solo', label: 'Solo Travel' },
    { value: 'couple', label: 'Couple' },
    { value: 'family', label: 'Family with Kids' },
    { value: 'friends', label: 'Group of Friends' },
  ];

  const handlePreferenceChange = (category: keyof typeof preferences, value: string) => {
    setPreferences({
      ...preferences,
      [category]: value
    });
  };

  const generateRecommendations = () => {
    // In a real app, this would involve AI logic to match preferences
    // For this demo, we'll just randomly select a subset of destinations
    const shuffled = [...FEATURED_DESTINATIONS].sort(() => 0.5 - Math.random());
    setRecommendedDestinations(shuffled.slice(0, 4));
    setShowRecommendations(true);
  };

  const provideFeedback = (destinationId: string, isPositive: boolean) => {
    // In a real app, this would send feedback to improve recommendations
    console.log(`Feedback for ${destinationId}: ${isPositive ? 'positive' : 'negative'}`);
    
    // Update the UI to show feedback was recorded
    const updatedDestinations = recommendedDestinations.map(dest => {
      if (dest.id === destinationId) {
        return {
          ...dest,
          feedbackGiven: true,
          positiveRating: isPositive
        };
      }
      return dest;
    });
    
    setRecommendedDestinations(updatedDestinations);
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-4xl mx-auto"
      >
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Personalized Recommendations</h1>
          <p className="text-lg text-gray-600">
            Tell us your preferences and we'll suggest the perfect destinations for you
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-10">
          <div className="p-6 sm:p-8">
            <div className="flex items-center mb-6">
              <Filter className="h-6 w-6 text-blue-600 mr-3" />
              <h2 className="text-xl font-semibold text-gray-900">Your Travel Preferences</h2>
            </div>
            
            <div className="space-y-6">
              {/* Climate Preference */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  What climate do you prefer?
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {climateOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => handlePreferenceChange('climate', option.value)}
                      className={`border rounded-md px-4 py-2 text-sm font-medium ${
                        preferences.climate === option.value
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'border-gray-300 text-gray-700 hover:border-blue-400'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Activity Type */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  What type of activities interest you?
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {activityOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => handlePreferenceChange('activity', option.value)}
                      className={`border rounded-md px-4 py-2 text-sm font-medium ${
                        preferences.activity === option.value
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'border-gray-300 text-gray-700 hover:border-blue-400'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Budget */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  What's your budget?
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {budgetOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => handlePreferenceChange('budget', option.value)}
                      className={`border rounded-md px-4 py-2 text-sm font-medium ${
                        preferences.budget === option.value
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'border-gray-300 text-gray-700 hover:border-blue-400'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Trip Duration */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  How long is your trip?
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {durationOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => handlePreferenceChange('duration', option.value)}
                      className={`border rounded-md px-4 py-2 text-sm font-medium ${
                        preferences.duration === option.value
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'border-gray-300 text-gray-700 hover:border-blue-400'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Travel Style */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Who are you traveling with?
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {travelStyleOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => handlePreferenceChange('travelStyle', option.value)}
                      className={`border rounded-md px-4 py-2 text-sm font-medium ${
                        preferences.travelStyle === option.value
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'border-gray-300 text-gray-700 hover:border-blue-400'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="pt-4">
                <button
                  onClick={generateRecommendations}
                  className="w-full py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center"
                >
                  <Compass className="h-5 w-5 mr-2" /> 
                  Get Personalized Recommendations
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Recommendations Section */}
        {showRecommendations && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Your Personalized Recommendations</h2>
              <p className="text-gray-600">
                Based on your preferences, we think you'll love these destinations
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {recommendedDestinations.map((destination, index) => (
                <motion.div
                  key={destination.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white rounded-lg overflow-hidden shadow-md"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={destination.imageUrl} 
                      alt={destination.name} 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-0 right-0 p-3">
                      <button className="text-white hover:text-red-500 transition-colors duration-200">
                        <Heart className={`h-6 w-6 ${destination.isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
                      </button>
                    </div>
                  </div>
                  
                  <div className="p-4">
                    <div className="flex items-center text-blue-600 text-sm mb-1">
                      <MapPin className="h-4 w-4 mr-1" />
                      <span>{destination.country}</span>
                    </div>
                    <h3 className="font-bold text-lg text-gray-900 mb-2">{destination.name}</h3>
                    <p className="text-gray-600 text-sm mb-4">{destination.description}</p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                        {preferences.climate === 'warm' ? 'Warm Climate' : 
                         preferences.climate === 'mild' ? 'Mild Climate' : 
                         preferences.climate === 'cold' ? 'Cold Climate' : 'Tropical Climate'}
                      </span>
                      <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                        {preferences.activity === 'culture' ? 'Cultural Hotspot' : 
                         preferences.activity === 'nature' ? 'Nature Paradise' : 
                         preferences.activity === 'beach' ? 'Beach Destination' : 
                         preferences.activity === 'food' ? 'Food Haven' : 'Adventure Hub'}
                      </span>
                      <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">
                        {preferences.budget === 'budget' ? 'Budget-Friendly' : 
                         preferences.budget === 'moderate' ? 'Moderately Priced' : 'Luxury Experience'}
                      </span>
                    </div>

                    <div className="flex justify-between items-center">
                      <a
                        href={`/destinations/${destination.id}`}
                        className="text-blue-600 text-sm font-medium hover:text-blue-700 flex items-center"
                      >
                        View Details <span className="ml-1">→</span>
                      </a>
                      
                      {!destination.feedbackGiven ? (
                        <div className="flex items-center space-x-2">
                          <button 
                            onClick={() => provideFeedback(destination.id, true)}
                            className="p-1 text-gray-400 hover:text-green-500 transition-colors"
                            aria-label="Good recommendation"
                          >
                            <ThumbsUp className="h-5 w-5" />
                          </button>
                          <button 
                            onClick={() => provideFeedback(destination.id, false)}
                            className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                            aria-label="Bad recommendation"
                          >
                            <ThumbsDown className="h-5 w-5" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-sm text-gray-500">
                          {destination.positiveRating ? 'Liked ✓' : 'Disliked ✓'}
                        </span>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default Recommendations;