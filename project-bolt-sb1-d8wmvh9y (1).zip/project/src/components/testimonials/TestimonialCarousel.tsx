import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

import { TESTIMONIALS } from '../../data/testimonials';

const TestimonialCarousel: React.FC = () => {
  const [current, setCurrent] = useState(0);
  const [direction, setDirection] = useState(0);
  const testimonials = TESTIMONIALS;

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setDirection(1);
      setCurrent((prevCurrent) => (prevCurrent + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [testimonials.length]);

  const goToPrev = () => {
    setDirection(-1);
    setCurrent((prevCurrent) => 
      prevCurrent === 0 ? testimonials.length - 1 : prevCurrent - 1
    );
  };

  const goToNext = () => {
    setDirection(1);
    setCurrent((prevCurrent) => (prevCurrent + 1) % testimonials.length);
  };

  return (
    <div className="relative max-w-4xl mx-auto">
      <div className="relative h-80 overflow-hidden">
        <AnimatePresence custom={direction} mode="wait">
          <motion.div
            key={current}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 0.5 }}
            className="absolute inset-0 flex flex-col items-center justify-center text-center px-4"
          >
            <div className="w-20 h-20 mb-6 rounded-full overflow-hidden border-4 border-blue-100">
              <img 
                src={testimonials[current].avatar} 
                alt={testimonials[current].name} 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex mb-4">
              {[...Array(5)].map((_, i) => (
                <Star 
                  key={i} 
                  className={`h-5 w-5 ${i < testimonials[current].rating ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'}`} 
                />
              ))}
            </div>
            <p className="text-lg text-gray-700 mb-6 italic">
              "{testimonials[current].text}"
            </p>
            <div>
              <p className="font-semibold text-gray-900">{testimonials[current].name}</p>
              <p className="text-sm text-gray-500">{testimonials[current].destination}</p>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      <button 
        onClick={goToPrev}
        className="absolute top-1/2 left-0 -translate-y-1/2 bg-white rounded-full p-2 shadow-md hover:bg-gray-100 focus:outline-none"
      >
        <ChevronLeft className="h-5 w-5 text-gray-600" />
      </button>
      <button 
        onClick={goToNext}
        className="absolute top-1/2 right-0 -translate-y-1/2 bg-white rounded-full p-2 shadow-md hover:bg-gray-100 focus:outline-none"
      >
        <ChevronRight className="h-5 w-5 text-gray-600" />
      </button>

      <div className="flex justify-center mt-6 space-x-2">
        {testimonials.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setDirection(index > current ? 1 : -1);
              setCurrent(index);
            }}
            className={`w-2 h-2 rounded-full ${
              current === index ? 'bg-blue-600' : 'bg-gray-300'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default TestimonialCarousel;