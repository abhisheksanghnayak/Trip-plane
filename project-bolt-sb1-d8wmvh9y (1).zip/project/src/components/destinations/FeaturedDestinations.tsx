import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin } from 'lucide-react';

import { FEATURED_DESTINATIONS } from '../../data/destinations';

interface DestinationCardProps {
  destination: typeof FEATURED_DESTINATIONS[0];
  index: number;
}

const DestinationCard: React.FC<DestinationCardProps> = ({ destination, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      whileHover={{ y: -5 }}
      className="rounded-lg overflow-hidden shadow-md bg-white"
    >
      <div className="relative h-48 overflow-hidden">
        <img 
          src={destination.imageUrl} 
          alt={destination.name} 
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
        />
        {destination.featured && (
          <div className="absolute top-3 right-3 bg-blue-600 text-white text-xs px-2 py-1 rounded-full">
            Featured
          </div>
        )}
      </div>
      <div className="p-4">
        <div className="flex items-center text-blue-600 text-sm mb-1">
          <MapPin className="h-4 w-4 mr-1" />
          <span>{destination.country}</span>
        </div>
        <h3 className="font-bold text-lg text-gray-900 mb-2">{destination.name}</h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{destination.description}</p>
        <Link
          to={`/destinations/${destination.id}`}
          className="text-blue-600 text-sm font-medium hover:text-blue-700 flex items-center"
        >
          Explore <span className="ml-1">→</span>
        </Link>
      </div>
    </motion.div>
  );
};

const FeaturedDestinations: React.FC = () => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {FEATURED_DESTINATIONS.map((destination, index) => (
        <DestinationCard key={destination.id} destination={destination} index={index} />
      ))}
    </div>
  );
};

export default FeaturedDestinations;