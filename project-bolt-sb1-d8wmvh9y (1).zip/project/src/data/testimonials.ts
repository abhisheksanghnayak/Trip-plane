export const TESTIMONIALS = [
  {
    id: '1',
    name: 'Sophie Martin',
    avatar: 'https://images.pexels.com/photos/2726111/pexels-photo-2726111.jpeg?auto=compress&cs=tinysrgb&w=100',
    destination: 'Paris, France',
    rating: 5,
    text: 'WanderNest made planning my Paris trip so simple! The budget calculator was spot-on and the personalized recommendations matched my interests perfectly. Will definitely use it for my next adventure!'
  },
  {
    id: '2',
    name: 'James Wilson',
    avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=100',
    destination: 'Bali, Indonesia',
    rating: 5,
    text: 'I was overwhelmed with planning my honeymoon until I found WanderNest. The itinerary tool helped us organize our dream trip to Bali with the perfect balance of relaxation and adventure.'
  },
  {
    id: '3',
    name: 'Elena Rodriguez',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100',
    destination: 'Kyoto, Japan',
    rating: 4,
    text: 'As a solo traveler, finding authentic experiences is important to me. WanderNest\'s recommendations for Kyoto led me to hidden gems I would have never discovered on my own!'
  },
  {
    id: '4',
    name: 'Michael Chen',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100',
    destination: 'New York City, USA',
    rating: 5,
    text: 'The budget calculator saved our family trip to NYC! We were able to plan our expenses accurately and enjoy the city without constantly worrying about overspending. Brilliant tool!'
  },
  {
    id: '5',
    name: 'Olivia Johnson',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100',
    destination: 'Cape Town, South Africa',
    rating: 5,
    text: 'WanderNest helped me discover Cape Town\'s diverse attractions and create a balanced itinerary with both adventure and cultural experiences. The trip planner is intuitive and comprehensive!'
  }
];